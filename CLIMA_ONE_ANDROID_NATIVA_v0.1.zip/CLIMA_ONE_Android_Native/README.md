# CLIMA ONE · Android nativa · Alpha tecnica 0.1

Questa è una **app Android originale** (nessuna dipendenza da PC durante l'uso) con comunicazione diretta sulla LAN tramite TCP e UDP. È un **progetto sorgente**, non un APK precompilato. La connessione fisica con specifici climatizzatori non è stata ancora provata.

## Compilazione

Aprire la cartella in Android Studio (Gradle 8.13 / Android SDK 35 / JDK 17), attendere sync e premere **Run**, oppure **Build > Build APK(s)**. In alternativa caricare i sorgenti in un repository GitHub privato: `.github/workflows/build-apk.yml` compila un APK debug scaricabile dagli Artifacts del workflow, senza installare Android Studio sul proprio PC. Il workflow non è ancora stato eseguito in questa sessione.

## In app

1. Collegare il telefono alla rete Wi-Fi su cui è associato il climatizzatore.
2. Usare *Trova climatizzatori*. La scansione UDP identifica il protocollo reale, non il marchio sull'etichetta.
3. Se un dispositivo è V2, provare *Leggi stato reale*.
4. Se è V3, collegare l'account **Midea SmartHome** a cui è già associato (e NON fornire password in chat), oppure importare direttamente un token/key ottenuti legittimamente. I dati di accesso SmartHome non vengono salvati; la chiave del climatizzatore viene cifrata nel Keystore del telefono.
5. Leggere stato, frequenze e potenza (solo se supportate); quindi provare controllo ON/OFF, temperatura, modalità, ventilazione ed ECO.

## Supporto OEM

La compatibilità non è deducibile solo dal produttore (Midea, Bosch, Ferroli, Clivet, Ariston, Olimpia Splendid, ecc.). Per le unità realmente Midea LAN V2/V3 la parte trasporto è condivisa; autenticazione e comandi specifici possono variare. Un climatizzatore associato alla sola app Bosch/Ariston potrebbe non poter essere autenticato tramite l'account SmartHome: la casistica rimane da sviluppare.

## Limitazioni dichiarate

- Implementazione **non ancora provata sul Midea BreezeleSS+ dell'utente**. Potrebbero servire aggiustamenti di parsing, handshake, credenziali, versioni e capability discovery.
- Per firmware V3 Midea e gli endpoint SmartHome sono non ufficiali e possono cambiare/essere bloccati. Non è garantito che un account SmartHome riesca sempre a recuperare il token.
- Controlli solo nei limiti standard: **non** modifica firmware, velocità massima fisica del ventilatore, frequenza compressore, limiti di sicurezza.
- La schermata diagnostica usa dati del protocollo: "non disponibile" se la macchina non risponde. Nessun valore fittizio.
- Il consumo in kWh e lo storico euro saranno abilitati dopo calibrazione degli endpoint energetici sul dispositivo reale. La potenza in W, quando disponibile, non costituisce un contatore elettrico certificato.
- Comunicazione locale sulla stessa rete, non controllo cloud fuori casa.
- La versione iOS richiederà un progetto Swift/Network Framework separato con autorizzazione rete locale e firma Apple.

## Architettura

- `app/src/main/java/com/climaone/app/core/MideaLan.java`: ricerca UDP 6445/20086, pacchetti V2, handshake V3, crittografia, query, scrittura dei parametri ordinari, lettura risposta.
- `SmartHomeCloud.java`: autenticazione facoltativa via HTTPS con **il proprio** account SmartHome (non fornisce altre credenziali preconfezionate).
- `PrivateKeys.java`: token e chiave cifrati Android Keystore.
- `MainActivity.java`: UI Android nativa multi-dispositivo; nessun WebView e nessun PC-gateway.

## Riferimenti e attribuzione

Il protocollo LAN è stato studiato utilizzando la documentazione e il codice del progetto **msmart-ng** (MIT, mill1000/midea-msmart), https://github.com/mill1000/midea-msmart . Verificare la versione corrente delle licenze e delle condizioni del produttore prima di distribuire commercialmente.

## Sicurezza

Utilizzare soltanto sui dispositivi propri o che si è autorizzati a controllare. Nessuna installazione di firmware intermarca o alterazione di protezioni inverter. Effettuare le prime prove in condizioni controllate; qualsiasi comando non confermato va verificato anche dal telecomando originale.

## Test effettuati qui

È stato eseguito `javac ... MideaLan.java tests/TestLan.java` seguito dal test su JVM locale: frame query, codifica V2, scrittura controllo, interpretazione stato, discovery V2/V3, scambio TCP V2 e autenticazione/scambio TCP V3 su server simulati. **Tutti superati.** Anche `SmartHomeCloud.java` è stato controllato con i tipi JSON sostitutivi, ma non è stato possibile provarlo contro le API reali.

Non è stato possibile generare un APK nell'ambiente corrente (mancano Android SDK e Gradle e il runtime non ha accesso alle repository Android). Non sono stati eseguiti test su smartphone, su uno split Midea reale né sui sistemi OEM. La procedura di build cloud inclusa è predisposta, ma richiede l'esecuzione in un repository GitHub.
